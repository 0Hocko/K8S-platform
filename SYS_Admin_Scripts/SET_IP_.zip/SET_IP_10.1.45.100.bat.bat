@echo off
set ip_naslov=10.1.45.100 255.255.0.0
netsh interface ipv4 set address name="Ethernet" static %ip_naslov%
::netsh interface set interface name="Ethernet" admin=DISABLED
::timeout /t 1
::netsh interface set interface name="Ethernet" admin=ENABLED
::timeout /t 3
IF %ERRORLEVEL% EQU 0 Echo IP Successfuly Changed To : %ip_naslov%
::IF %ERRORLEVEL% NEQ 0 Echo IP is already 10.1.45.100
timeout /t 4 >nul
